﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class People
    {
        public int age { get; set; }
        public string name { get; set; }
        public int address { get; set; }

        public void addPeople(ref List<People> people, int age, string name, int address)
        {
            people.Add(new People() { age = age, name = name, address = address });
        }
    }

    public class Sort<T>
    {
        public delegate int Compare(T dt1, T dt2);
        public List<T> list = null;
        public Sort(List<T> l)
        {
            list = l;
        }

        public List<T> Data
        {
            get
            {
                return list;
            }
        }

        public void doSort(Compare cmpfunc, bool mode)
        {
            T curr;
            for (int i = 0; i < list.Count(); i++)
            {
                for (int j = i + 1; j < list.Count(); j++)
                {
                    if (mode)
                    {
                        if (cmpfunc(list[i], list[j]) == 1)
                        {
                            curr = list[i];
                            list[i] = list[j];
                            list[j] = curr;
                        }
                    }
                    else
                    {
                        if (cmpfunc(list[i], list[j]) == -1)
                        {
                            curr = list[j];
                            list[j] = list[i];
                            list[i] = curr;
                        }
                    }
                }
            }
        }

        public static int CompareByPeopleAge(People s1, People s2)
        {
            return s1.age.CompareTo(s2.age);
        }

        public static int CompareByPeopleAddress(People s1, People s2)
        {
            return s1.address.CompareTo(s2.address);
        }

        public static int CompareByPeopleName(People s1, People s2)
        {
            return s1.name.CompareTo(s2.name);
        }

        public void GetResult(List<People> people, int type, bool mode)
        {
            if (type == 1)
            {
                if (mode)
                {
                    Console.WriteLine("Sort By Age ASC");
                }
                else
                {
                    Console.WriteLine("Sort By Age DESC");
                }
                foreach (var lst in people)
                {
                    Console.WriteLine(lst.age + " " + lst.name + " " + lst.address);
                }
            }
            else if (type == 2)
            {
                if (mode)
                {
                    Console.WriteLine("Sort By Name ASC");
                }
                else
                {
                    Console.WriteLine("Sort By Name DESC");
                }
                foreach (var lst in people)
                {
                    Console.WriteLine(lst.name + " " + lst.age + " " + lst.address);
                }
            }
            else
            {
                if (mode)
                {
                    Console.WriteLine("Sort By Address ASC");
                }
                else
                {
                    Console.WriteLine("Sort By Address DESC");
                }
                foreach (var lst in people)
                {
                    Console.WriteLine(lst.address + " " + lst.name + " " + lst.age);
                }
            }
            Console.WriteLine();
        }
    }

    class Program
    {
        static List<People> CreatePeople()
        {
            List<People> people = new List<People>();
            People pp = new People();
            pp.addPeople(ref people, 24, "Mark", 15);
            pp.addPeople(ref people, 35, "Steve", 258);
            pp.addPeople(ref people, 24, "Michael", 999);
            pp.addPeople(ref people, 16, "Bill", 748);
            pp.addPeople(ref people, 70, "Kelvin", 456);
            pp.addPeople(ref people, 24, "Michae", 666);
            return people;
        }

        //init people
        static List<People> people = CreatePeople();

        static void Main(string[] args)
        {
            // init sort
            Sort<People> sort = new Sort<People>(people);

            /* Sort By Age */
            // Compare People Age, true : [ASC]
            sort.doSort(Sort<People>.CompareByPeopleAge, true);
            sort.GetResult(people, 1, true); // Print

            /* Sort By Name */
            // Compare People Name, true : [DESC]
            sort.doSort(Sort<People>.CompareByPeopleName, false);
            sort.GetResult(people, 2, false); // Print

            /* Sort By Address */
            // Compare People Address, true : [ASC]
            sort.doSort(Sort<People>.CompareByPeopleAddress, true);
            sort.GetResult(people, 3, true); // Print

            Console.ReadLine();
        }
    }
}
