﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class People
    {
        public int age { get; set; }
        public string name { get; set; }
        public int address { get; set; }
    }
    class Program
    {
        public static int Compare<T>(T first, T second)
        {
            return Comparer<T>.Default.Compare(first, second);
        }

        static List<People> CreatePeople()
        {
            return new List<People>();
        }

        static void AddPeople(ref List<People> people, int age, string name, int address)
        {
            people.Add(new People() { age = age, name = name, address = address });
        }

        static void SortByAgeASC(ref List<People> people)
        {
            People curr;
            for (int i = 0; i < people.Count(); i++)
            {
                for (int j = i + 1; j < people.Count(); j++)
                {
                    if (Compare(people[i].age, people[j].age) == 1)
                    {
                        curr = people[i];
                        people[i] = people[j];
                        people[j] = curr;
                    }
                }
            }
        }

        static void SortByAgeDESC(ref List<People> people)
        {
            People curr;
            for (int i = 0; i < people.Count(); i++)
            {
                for (int j = i + 1; j < people.Count(); j++)
                {
                    if (Compare(people[j].age, people[i].age) == 1)
                    {
                        curr = people[j];
                        people[j] = people[i];
                        people[i] = curr;
                    }
                }
            }
        }

        static void SortByNameASC(ref List<People> people)
        {
            People curr;
            int k = 0;
            for (int i = 0; i < people.Count(); i++)
            {
                for (int j = i + 1; j < people.Count(); j++)
                {
                    Console.WriteLine(people[i].name + " " + people[j].name);
                    if ((int)people[i].name.ToCharArray()[k] > (int)people[j].name.ToCharArray()[k])
                    {
                        curr = people[j];
                        people[j] = people[i];
                        people[i] = curr;
                    } else if ((int)people[i].name.ToCharArray()[k] == (int)people[j].name.ToCharArray()[k])
                    {
                        k++;
                        if (people[i].name.Length > people[j].name.Length)
                        {
                            if ((int)people[i].name.ToCharArray()[k] > (int)people[j].name.ToCharArray()[k] && (int)people[i].name.ToCharArray()[k] != 32 && (int)people[j].name.ToCharArray()[k] != 32)
                            {
                                curr = people[j];
                                people[j] = people[i];
                                people[i] = curr;
                                break;
                            }
                            else
                            {
                                if ((int)people[j].name.ToCharArray()[k] != 32)
                                {
                                    curr = people[i];
                                    people[i] = people[j];
                                    people[j] = curr;
                                }
                            }
                        }
                    }
                }
            }
        }

        static void SortByNameDESC(ref List<People> people)
        {
            People curr;
            int k = 0;
            for (int i = 0; i < people.Count(); i++)
            {
                for (int j = i + 1; j < people.Count(); j++)
                {
                    if ((int)people[i].name.ToCharArray()[0] < (int)people[j].name.ToCharArray()[0])
                    {
                        curr = people[i];
                        people[i] = people[j];
                        people[j] = curr;
                    }
                    else if ((int)people[i].name.ToCharArray()[k] == (int)people[j].name.ToCharArray()[k])
                    {
                        k++;
                        if (people[i].name.Length < people[j].name.Length)
                        {
                            if ((int)people[i].name.ToCharArray()[k] < (int)people[j].name.ToCharArray()[k] && (int)people[i].name.ToCharArray()[k] != 32 && (int)people[j].name.ToCharArray()[k] != 32)
                            {
                                curr = people[i];
                                people[i] = people[j];
                                people[j] = curr;
                            }
                            else
                            {
                                if ((int)people[i].name.ToCharArray()[k] != 32)
                                {
                                    curr = people[i];
                                    people[i] = people[j];
                                    people[j] = curr;
                                }
                            }
                            k++;
                        }
                    }
                }
            }
        }

        static void SortByAddressASC(ref List<People> people)
        {
            People curr;
            for (int i = 0; i < people.Count(); i++)
            {
                for (int j = i + 1; j < people.Count(); j++)
                {
                    if (Compare(people[i].address, people[j].address) == 1)
                    {
                        curr = people[i];
                        people[i] = people[j];
                        people[j] = curr;
                    }
                }
            }
        }

        static void SortByAddressDESC(ref List<People> people)
        {
            People curr;
            for (int i = 0; i < people.Count(); i++)
            {
                for (int j = i + 1; j < people.Count(); j++)
                {
                    if (Compare(people[j].address, people[i].address) == 1)
                    {
                        curr = people[j];
                        people[j] = people[i];
                        people[i] = curr;
                    }
                }
            }
        }

        static void PrintPeople(List<People> people)
        {
            foreach (var p in people)
            {
                Console.WriteLine(p.name + " " + p.age + " " + p.address);
            }
            Console.ReadLine();
        }

        static void OrderPeople()
        {
            //init people
            List<People> people = CreatePeople();
            AddPeople(ref people, 24, "Mark", 152);
            AddPeople(ref people, 35, "Steve", 258);
            AddPeople(ref people, 24, "Michael", 999);
            AddPeople(ref people, 16, "Bill", 748);
            AddPeople(ref people, 70, "Kelvin", 456);
            AddPeople(ref people, 24, "Michae", 666);

            //sort by properties
            //SortByAgeASC(ref people);
            //SortByAgeDESC(ref people);
            SortByNameASC(ref people);
            //SortByNameDESC(ref people);
            //SortByAddressASC(ref people);
            //SortByAddressDESC(ref people);
            PrintPeople(people);
        }

        static void Main(string[] args)
        {
            OrderPeople();
        }
    }
}
